package com.example.learning_tool;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    private Dictionary model;
    Translation randomEx;

    public Controller() {
        this.model = new Dictionary();
        this.randomEx = model.selectRandomTranslation();
    }

    @FXML
    private Button submit;

    @FXML
    private Button add;

    @FXML
    private Label englishL;

    @FXML
    private Label germanL;

    @FXML
    private TextField input;

    @FXML
    private Label checkL;

    @FXML
    private TextField addGer;

    @FXML
    private TextField addEng;

    @FXML
    private TextField addSol;

    @FXML
    private Button addT;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        germanL.setText(randomEx.getGerman());
        englishL.setText(randomEx.getEnglish());

    }

    @FXML
    private void buttonHandler(ActionEvent event) throws InterruptedException {
        if (event.getSource() instanceof Button) {
            Button tmp = (Button) event.getSource();
            switch (tmp.getId()) {
                case "add" -> {
                    System.out.println("add");
                    try {
                        FXMLLoader fxmlLoader = new FXMLLoader();
                        fxmlLoader.setLocation(getClass().getResource("add-view.fxml"));
                        Scene scene = new Scene(fxmlLoader.load(), 605, 486);
                        //Stage stage = new Stage();
                        //stage.setTitle("Add Translation");
                        //stage.setScene(scene);
                        //stage.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                case "submit" -> {
                    System.out.println("submit");
                    String randomSol = randomEx.getSolution();
                    if (Objects.equals(input.getText(), randomSol)) {
                        System.out.println("true");
                        checkL.setText("Correct answer");
                    } else {
                        System.out.println("false");
                        checkL.setText("Wrong answer");
                    }
            }
            }
        }
    }

}